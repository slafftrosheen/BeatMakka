# Needle Quay local demo

Run `./Launch-NeedleQuay.ps1` in PowerShell, then press Play in Studio. The launcher verifies and installs only the `needle-quay` content namespace in your installed Studio version. Rerun it after a Studio update. Use `-StudioExe <path>` to select a specific installation, or `-InstallOnly` to verify/install without opening Studio. No administrator rights, Python, server or account upload is needed for the portable ZIP.

Four parking venues, two personal Roamers, the sampler/Beat Shelf, Q00-Q12 and the six-phase finale are integrated. Use QUAY / MAP or M for the route journal; nearby actions support the large button and E/X shortcut. All 40 exact asset definitions are included, with eight local PBR finishes, NPC joint motion, authored signs and all 184 WAV bindings.

Unzip the entire portable package before launching. The place requires its companion content; the rbxlx alone is not the complete package. Saves in this unpublished Studio place are session-scoped. No cloud deployment or two-player/device acceptance is claimed. Nothing was uploaded or published.

Full source and evidence are in the repository's `docs/needle-quay/LOCAL_DEMO_2026-10-25.md`.
